export const CATEGORIES = {
  materials: "materials",
  furniture: "furniture",
  plumbing: "plumbing"
};

export const CATEGORY_LABELS = {
  [CATEGORIES.materials]: "Материалы",
  [CATEGORIES.furniture]: "Мебель",
  [CATEGORIES.plumbing]: "Сантехника"
};

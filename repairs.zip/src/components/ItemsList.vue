<template>
  <div>
    <Item v-for="item in items" :key="item.id" v-bind:item="item"></Item>
    <input v-model="name" />
    <button @click="createItem">Добавить</button>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import Item from "./Item.vue";

export default {
  data() {
    return { name: "" };
  },
  methods: {
    ...mapActions(["fetchItems", "addItem"]),
    createItem() {
      this.addItem(this.name);
      this.name = "";
    }
  },
  computed: {
    ...mapState(["items"]),
    item() {
      return this.items[0];
    }
  },
  components: {
    Item
  },
  created() {
    this.fetchItems();
  }
};
</script>

<style lang="scss" scoped>
</style>
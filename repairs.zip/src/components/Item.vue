<template>
  <div class="row">
    <div>{{formattedItem.date}}</div>
    <div>{{formattedItem.category}}</div>
    <div>{{formattedItem.name}}</div>
    <div>{{formattedItem.amount}}</div>
    <div><button @click="removeItem">Удалить</button></div>
  </div>
</template>

<script>
import moment from 'moment';
import { mapActions } from "vuex";
import { CATEGORY_LABELS } from "../constants/categories";

export default {
  props: ["item"],
  methods: {
    ...mapActions(["deleteItem"]),
    removeItem() {
      this.deleteItem(this.item.id)
    }
  },
  computed: {
    formattedItem() {
      const { item } = this;
      return {...item, category: CATEGORY_LABELS[item.category], date: moment(item.date.seconds).format("DD/MM/YYYY")}
    }
  }
};
</script>

<style lang="scss" scoped>
.row {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  grid-gap: 1rem;
}
</style>
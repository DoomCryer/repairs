import Vue from "vue";
import Vuex from "vuex";
import moment from "moment";
import fb from "../fire";

Vue.use(Vuex);

export default new Vuex.Store({
  state: { items: [] },
  mutations: {
    setItems(state, val) {
      state.items = val;
    }
  },
  actions: {
    fetchItems({ commit }) {
      fb.itemsCollection.get().then(docs => {
        let items = [];
        docs.forEach(doc => {
          let item = doc.data();
          item.id = doc.id;
          items.push(item);
        });
        commit("setItems", items);
      });
    },
    addItem({ dispatch }, name) {
      fb.itemsCollection
        .add({
          category: "materials",
          amount: 8812,
          date: moment().format("DD-MM-YYYY"),
          name
        })
        .then(dispatch("fetchItems"));
    },
    deleteItem({ dispatch }, id) {
      fb.itemsCollection
        .doc(id)
        .delete()
        .then(dispatch("fetchItems"));
    }
  },
  modules: {}
});
